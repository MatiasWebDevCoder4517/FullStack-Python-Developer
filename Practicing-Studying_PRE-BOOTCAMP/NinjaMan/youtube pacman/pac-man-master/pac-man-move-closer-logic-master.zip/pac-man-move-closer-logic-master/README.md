# pac-man-move-closer-logic
Making Blinky chase PacMan wherever he is on the board in vanilla javaScript
