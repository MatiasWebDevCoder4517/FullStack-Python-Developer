no me dio el tiempo para determinar el estilo completo de css para que quede exactamente igual al ejercicio

Subi hasta donde pude cumpliendo el tiempo determinado.