# Sample portfolio project

This assignment is to replicate the below image using HTML and CSS. View my submission here: https://ampetr89.github.io/dojo-wf-portfolio/.


![Sample portfolio](/img/portfolio_assignment.png)
