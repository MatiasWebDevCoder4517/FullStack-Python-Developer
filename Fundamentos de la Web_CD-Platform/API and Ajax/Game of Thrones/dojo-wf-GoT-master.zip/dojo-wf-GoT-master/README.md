# An API of Ice and Fire

The assignment was to display information about the four major houses in Game of Thrones. Click on the image to view details about the house. Data comes from [An API of Ice and Fire](https://www.anapioficeandfire.com), using the `/houses/` endpoint. 


Live demo here: https://ampetr89.github.io/dojo-wf-GoT/
